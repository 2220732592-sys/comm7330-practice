import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {generateSession,makeQuestion,families,initialMaterials} from '../../lib/generator.ts';
const candidates=[];
for(const f of families){const material=initialMaterials.find(m=>f.match.test(m.text));if(!material)throw Error('Missing source '+f.id);for(let i=0;i<12;i++)candidates.push(makeQuestion(f.id,20260921+i*91,material));}
const seed=generateSession(initialMaterials,'exam',10,undefined,undefined,20260921,1);
candidates.push(...seed.questions);
fs.writeFileSync('/tmp/com7330-candidates.json',JSON.stringify(candidates));
const p=spawnSync('python3',['scripts/qa/verify-python.py','/tmp/com7330-candidates.json'],{encoding:'utf8'});process.stdout.write(p.stdout);process.stderr.write(p.stderr);if(p.status)process.exit(p.status);
seed.questions.forEach(q=>q.verified=true);
fs.writeFileSync('lib/seed-exam.json',JSON.stringify(seed,null,2));
