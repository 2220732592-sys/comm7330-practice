import {unzipSync,strFromU8} from 'fflate';
export type Extracted={name:string;text:string;warnings:string[]};
export async function parseMaterial(file:File,depth=0):Promise<Extracted[]>{
 if(file.size>20*1024*1024)throw new Error('单个文件请控制在 20 MB 以内。');
 const ext=file.name.split('.').pop()?.toLowerCase();const bytes=new Uint8Array(await file.arrayBuffer());
 if(ext==='zip'){
  if(depth>0)throw new Error('暂不读取嵌套 ZIP。请解压后上传其中的资料。');
  let total=0,count=0;const entries=unzipSync(bytes,{filter:e=>{if(e.originalSize>20*1024*1024)throw new Error('ZIP 中单文件解压后超过 20 MB。');total+=e.originalSize;count++;if(total>60*1024*1024||count>100)throw new Error('ZIP 内容过大，请分批上传。');return /\.(pdf|pptx|docx|txt|py|ipynb)$/i.test(e.name)&&!e.name.startsWith('__MACOSX');}});const output:Extracted[]=[];
  for(const [name,data] of Object.entries(entries))output.push(...await parseMaterial(new File([new Uint8Array(data)],name),depth+1));
  if(!output.length)throw new Error('ZIP 中没有可读取的课程文件。');return output;
 }
 let text='',warnings:string[]=[];
 if(ext==='pdf'){
  const pdfjs=await import('pdfjs-dist');pdfjs.GlobalWorkerOptions.workerSrc=new URL('pdfjs-dist/build/pdf.worker.min.mjs',import.meta.url).href;const task=pdfjs.getDocument({data:bytes,useSystemFonts:true});const doc=await task.promise;
  try{if(doc.numPages>350)throw new Error('PDF 超过 350 页，请拆分上传。');for(let page=1;page<=doc.numPages;page++){const content=await(await doc.getPage(page)).getTextContent();text+=`\n[Page ${page}]\n`+content.items.map((i:any)=>i.str+(i.hasEOL?'\n':' ')).join('');}}finally{await task.destroy();}
  if(text.replace(/\[Page \d+\]/g,'').trim().length<40)throw new Error('该 PDF 没有足够的可提取文本，可能是扫描件。请上传带文本的 PDF、Notebook 或 TXT。');
 }else if(ext==='docx'||ext==='pptx'){
  let total=0;const entries=unzipSync(bytes,{filter:e=>{total+=e.originalSize;if(total>60*1024*1024)throw new Error('文档解压后过大。');return ext==='docx'?e.name==='word/document.xml':/^ppt\/slides\/slide\d+\.xml$/.test(e.name);}});
  for(const name of Object.keys(entries).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}))){const doc=new DOMParser().parseFromString(strFromU8(entries[name]),'application/xml');text+='\n['+name+']\n'+Array.from(doc.getElementsByTagNameNS('*','p')).map(p=>Array.from(p.getElementsByTagNameNS('*','t')).map(t=>t.textContent).join('')).join('\n');}
 }else if(ext==='ipynb'){const nb=JSON.parse(strFromU8(bytes));if(!Array.isArray(nb.cells))throw new Error('Notebook 缺少 cells 字段。');text=nb.cells.map((c:any)=>Array.isArray(c.source)?c.source.join(''):c.source||'').join('\n\n');}
 else if(['txt','py'].includes(ext||''))text=new TextDecoder('utf-8').decode(bytes);
 else if(ext==='ppt')throw new Error('旧版 .ppt 请在 PowerPoint 中另存为 .pptx 或 PDF 后上传。');
 else throw new Error('不支持此格式，请上传 PDF / PPTX / DOCX / TXT / PY / IPYNB / ZIP。');
 if(text.trim().length<20)throw new Error(file.name+' 未提取到足够的课程文本。');if(text.length>300000){warnings.push('仅分析前 300,000 字符。');text=text.slice(0,300000);}return [{name:file.name,text,warnings}];
}
