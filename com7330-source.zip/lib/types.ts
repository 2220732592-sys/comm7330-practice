export type TestCase = {input:string; expected:string; hidden:boolean; note:string; stdout?:string; stdin?:string};
export type Question = {id:string; family:string; title:string; description:string; translation:string; input:string; output:string; functionName:string; starter:string; solution:string; tests:TestCase[]; topic:string; subtopic:string; difficulty:'Easy'|'Medium'|'Hard'; marks:number; source:string; materialId:string; analysis:string; verified?:boolean};
export type TestResult = {status:string; actual:string; expected:string; input:string; stdout:string; error?:string; hidden:boolean; note:string; elapsed?:number; expectedStdout?:string};
export type Answer = {code:string; runs:number; submitted:boolean; results?:TestResult[]; visibleResults?:TestResult[]; submittedCode?:string; submittedAt?:string};
export type Session = {id:string; title:string; mode:'exam'|'practice'; questions:Question[]; answers:Record<string,Answer>; current:number; complete:boolean; created:string; completedAt?:string; materialIds:string[]};
export type Material = {id:string; name:string; text:string; topics:string[]; taskCount:number; created:string; original?:boolean; selected:boolean; warnings?:string[]; uploadKey?:string};
export type Workspace = {sessions:Session[]; activeId:string; materials:Material[]; revision?:number};
