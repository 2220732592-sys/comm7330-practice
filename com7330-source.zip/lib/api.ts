const API_ORIGIN = import.meta.env.VITE_API_ORIGIN || 'https://python-sandbox-api-production.up.railway.app';
const TOKEN_KEY = 'com7330-pages-visitor-v1';
let sessionRequest: Promise<string> | undefined;

async function visitorToken(): Promise<string> {
 const existing = localStorage.getItem(TOKEN_KEY);
 if(existing) return existing;
 if(!sessionRequest) sessionRequest=(async()=>{
  const response=await fetch(API_ORIGIN+'/api/session',{method:'POST',credentials:'omit',signal:AbortSignal.timeout(20000)});
  const data=await response.json();
  if(!response.ok||typeof data.token!=='string') throw new Error(data.error||'无法连接练习服务器，请稍后重试。');
  localStorage.setItem(TOKEN_KEY,data.token);
  return data.token as string;
 })().catch(error=>{sessionRequest=undefined;throw error;});
 return sessionRequest;
}

export async function apiFetch(path:string,options:RequestInit={}):Promise<Response> {
 if(!['/api/workspace','/api/materials','/api/execute'].includes(path)) throw new Error('Unknown API route');
 const token=await visitorToken();
 const headers=new Headers(options.headers);
 headers.set('Authorization','Visitor '+token);
 return fetch(API_ORIGIN+path,{...options,headers,credentials:'omit',signal:options.signal||AbortSignal.timeout(45000)});
}
