import type {Answer,Question,Session,TestResult} from './types';
export const passed=(r:TestResult[])=>r.filter(x=>x.status==='Passed').length;
export const score=(q:Question,a?:Answer)=>a?.submitted&&a.results?Math.round(q.marks*passed(a.results)/q.tests.length*100)/100:0;
export const totalScore=(s:Session)=>Math.round(s.questions.reduce((n,q)=>n+score(q,s.answers[q.id]),0)*100)/100;
export const maxScore=(s:Session)=>s.questions.reduce((n,q)=>n+q.marks,0);
export function errorAnalysis(q:Question,r:TestResult[]){const bad=r.find(x=>x.status!=='Passed');if(!bad)return '全部测试通过。可以继续下一题。';const e=bad.error||'';if(bad.status==='Time Limit Exceeded')return '程序未在 3 秒内结束。检查 while 的更新条件、循环范围及是否存在无限循环。';if(bad.status==='Syntax Error')return '检查冒号、括号和缩进；请保留题目给定的函数名与参数。';if(e.includes('NotImplementedError'))return '请删除 raise NotImplementedError()，并完成函数。';if(e.includes('IndexError'))return '索引越界。先检查空输入，并确认最后一个有效索引是 len(...) - 1。';if(e.includes('TypeError'))return '数据类型不匹配。检查 int()/float() 转换、参数个数与集合/列表方法。';if(e.includes('NameError'))return '检查函数名、变量拼写，以及字符串是否加引号。';if(bad.actual==='None')return '函数没有返回期望结果。print() 只负责显示；请检查 return 及其缩进位置。';return q.analysis+' 先对照失败测试的实际输出与期望输出，再检查边界。';}
