import {apiFetch} from '@/lib/api';
import type {Question,TestResult} from './types';

export async function runQuestion(q:Question,code:string,all=false,onProgress?:(n:number,total:number)=>void):Promise<TestResult[]>{
 const tests=all?q.tests:q.tests.filter(test=>!test.hidden);
 onProgress?.(0,tests.length);
 let response:Response;
 try{
  response=await apiFetch('/api/execute',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({code,tests,preserveInputs:/do not modify|must remain unchanged/i.test(q.description)}),
   signal:AbortSignal.timeout(90000)});
 }catch{throw new Error('服务器运行连接中断或超时，代码仍已保留，请稍后重试。');}
 const data:any=await response.json();
 if(!response.ok)throw new Error(data.error||'服务器运行暂时不可用，请稍后重试。');
 if(data.execution!=='server'||!Array.isArray(data.results)||data.results.length!==tests.length)throw new Error('服务器返回的测试结果不完整，请重试。');
 onProgress?.(tests.length,tests.length);
 return data.results;
}

export async function verifyQuestions(questions:Question[],onProgress?:(n:number,total:number)=>void){
 for(let i=0;i<questions.length;i++){
  const q=questions[i];onProgress?.(i+1,questions.length);
  const results=await runQuestion(q,q.solution,true);
  if(results.some(r=>r.status!=='Passed'))throw new Error(`题目质量检查未通过：${q.title}。该题未加入试卷。`);
  q.verified=true;
 }
}
