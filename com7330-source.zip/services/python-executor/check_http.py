"""Checks the deployed executor using the ignored local preview configuration."""
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import urllib.request
import urllib.error

ROOT = Path(__file__).resolve().parents[2]
config = dict(line.split('=', 1) for line in (ROOT / '.env.local').read_text().splitlines() if '=' in line)
base = config['PYTHON_EXECUTOR_URL'].rstrip('/')


def request(path, data=None, authenticated=True):
    headers = {'Content-Type': 'application/json'}
    if authenticated:
        headers['Authorization'] = 'Bearer ' + config['PYTHON_EXECUTOR_KEY']
    req = urllib.request.Request(base + path, data=json.dumps(data).encode() if data is not None else None,
                                 headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=85) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as error:
        return error.code, error.read().decode()[:500]


status, health = request('/health', authenticated=False)
assert status == 200 and health['execution'] == 'server', (status, health)
print('PASS: public HTTPS health, server CPython, WASI isolation', flush=True)
questions = json.loads((ROOT / 'lib/seed-exam.json').read_text())['questions']
def grade(question):
    status, result = request('/execute', dict(code=question['solution'], tests=question['tests'],
        preserveInputs='do not modify' in question['description'].lower()))
    assert status == 200, (status, result)
    assert result['execution'] == 'server' and all(r['status'] == 'Passed' for r in result['results']), result
    return len(result['results'])

with ThreadPoolExecutor(max_workers=2) as pool:
    total = sum(pool.map(grade, questions))
print(f'PASS: {total} deployed reference tests, concurrent submissions', flush=True)
q = questions[0]
payload = dict(code=q['solution'], tests=q['tests'][:1])
assert request('/execute', payload, authenticated=False)[0] == 401
assert request('/execute', {'code': '', 'tests': []})[0] == 400
status, result = request('/execute', dict(payload, code='import time\ntime.sleep(1000)'))
assert status == 200 and result['results'][0]['status'] == 'Time Limit Exceeded', (status, result)
print('PASS: private executor authorization, request validation, 3-second hard timeout', flush=True)
