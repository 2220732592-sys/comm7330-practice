"""A fresh CPython/WASI instance for every test, with capability-based isolation."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import wasmtime

MEMORY_BYTES = 64 * 1024 * 1024
TIME_SECONDS = 3
OUTPUT_BYTES = 128 * 1024
FUEL = 3_000_000_000
RUNNER = (Path(__file__).parent / 'runner.py').read_text()


class Sandbox:
    def __init__(self, runtime=None, compiled=None):
        self.runtime = Path(runtime or os.environ['PYTHON_WASI_ROOT']).resolve()
        config = wasmtime.Config()
        config.consume_fuel = True
        config.epoch_interruption = True
        self.engine = wasmtime.Engine(config)
        # Deserialization is only used for our own freshly compiled, private cache.
        self.module = (wasmtime.Module.deserialize_file(self.engine, compiled) if compiled
                       else wasmtime.Module.from_file(self.engine, str(self.runtime / 'python.wasm')))
        self.stopping = threading.Event()
        self.clock = threading.Thread(target=self._clock, daemon=True)
        self.clock.start()

    def _clock(self):
        while not self.stopping.wait(0.1):
            self.engine.increment_epoch()

    def close(self):
        self.stopping.set()
        self.clock.join()
        self.module.close()
        self.engine.close()

    def run_case(self, code, test, preserve_inputs=False):
        base = dict(input=test['input'], expected=test['expected'], hidden=test['hidden'],
                    note=test.get('note', ''), actual='', stdout='', status='Runtime Error')
        if 'stdout' in test:
            base['expectedStdout'] = test['stdout']
        started = time.monotonic()
        output, errors = b'', b''
        output_dir = Path(os.environ['WASM_OUTPUT_DIR'])
        stdout_path, stderr_path = output_dir / 'stdout', output_dir / 'stderr'

        payload = json.dumps(dict(code=code, test=test, preserveInputs=preserve_inputs))
        script = RUNNER + '\nprint(run_case(' + repr(payload) + '))\n'
        wasi = wasmtime.WasiConfig()
        wasi.argv = ['python', '-B', '-S', '-c', script]
        # Do not inherit host env, stdin, network handles, or any writable directory.
        wasi.env = [('PYTHONHOME', '/runtime'), ('PYTHONDONTWRITEBYTECODE', '1')]
        wasi.preopen_dir(str(self.runtime / 'lib'), '/runtime/lib', fs_mutable=False)
        # Native bounded files avoid Python callbacks running during Rust shutdown.
        # The parent owns this temporary directory and removes it even on timeout.
        # Guests receive only stdout/stderr descriptors, never the directory itself.
        wasi.stdout_file = str(stdout_path)
        wasi.stderr_file = str(stderr_path)
        try:
            # Explicit destruction also releases WASI callbacks before interpreter exit.
            with wasmtime.Store(self.engine) as store:
                store.set_limits(memory_size=MEMORY_BYTES, table_elements=20000,
                                 instances=1, memories=1, tables=1)
                store.set_fuel(FUEL)
                store.set_epoch_deadline(TIME_SECONDS * 10)
                store.set_wasi(wasi)
                with wasmtime.Linker(self.engine) as linker:
                    linker.define_wasi()
                    instance = linker.instantiate(store, self.module)
                    instance.exports(store)['_start'](store)
            with stdout_path.open('rb') as stream:
                output = stream.read(OUTPUT_BYTES + 1)
            with stderr_path.open('rb') as stream:
                errors = stream.read(OUTPUT_BYTES + 1)
            if len(output) + len(errors) > OUTPUT_BYTES:
                base['error'] = 'Output limit exceeded.'
            else:
                result = json.loads(output.decode('utf-8'))
                if not isinstance(result, dict) or result.get('status') not in {'Passed', 'Failed', 'Syntax Error', 'Runtime Error'}:
                    raise ValueError('Invalid result')
                for key in ['actual', 'stdout', 'error']:
                    if key in result:
                        base[key] = str(result[key])[:30000]
                base['status'] = result['status']
        except wasmtime.Trap as error:
            if error.trap_code in {wasmtime.TrapCode.INTERRUPT, wasmtime.TrapCode.OUT_OF_FUEL}:
                base['status'] = 'Time Limit Exceeded'
                base['error'] = 'Execution exceeded the 3-second CPU/work budget.'
            else:
                base['error'] = 'Python sandbox stopped: memory, stack or execution limit reached.'
        except (ValueError, UnicodeError, wasmtime.WasmtimeError) as error:
            base['error'] = 'Output limit exceeded.' if output_exceeded else 'Python exited without a valid result.'
            if errors:
                base['error'] += '\n' + errors.decode('utf-8', errors='replace')[-2000:]
        base['elapsed'] = round((time.monotonic() - started) * 1000, 2)
        return base

    def run_question(self, data):
        return [self.run_case(data['code'], test, data.get('preserveInputs', False))
                for test in data['tests']]


class Executor:
    """OS watchdog also interrupts blocking WASI calls such as time.sleep()."""
    def __init__(self):
        self.runtime = os.environ['PYTHON_WASI_ROOT']
        self.cache = tempfile.TemporaryDirectory(prefix='com7330-wasi-')
        self.compiled = str(Path(self.cache.name) / 'python.cwasm')
        compiler = Sandbox()
        try:
            Path(self.compiled).write_bytes(compiler.module.serialize())
        finally:
            compiler.close()

    def close(self):
        self.cache.cleanup()

    def run_case(self, code, test, preserve_inputs=False):
        base = dict(input=test['input'], expected=test['expected'], hidden=test['hidden'],
                    note=test.get('note', ''), actual='', stdout='', status='Runtime Error')
        if 'stdout' in test:
            base['expectedStdout'] = test['stdout']
        data = dict(code=code, test=test, preserveInputs=preserve_inputs)
        # No backend authentication key or other Railway variables reach this process.
        capture = tempfile.TemporaryDirectory(prefix='com7330-output-')
        worker_env = {'PYTHON_WASI_ROOT': self.runtime, 'WASM_COMPILED_PATH': self.compiled, 'WASM_OUTPUT_DIR': capture.name,
                      'PYTHONDONTWRITEBYTECODE': '1', 'LANG': 'C.UTF-8'}
        if os.environ.get('PYTHONPATH'):
            worker_env['PYTHONPATH'] = os.environ['PYTHONPATH']
        started = time.monotonic()
        try:
            completed = subprocess.run([sys.executable, str(Path(__file__).parent / 'case_worker.py')],
                                       input=json.dumps(data), text=True, capture_output=True,
                                       env=worker_env, timeout=TIME_SECONDS, check=False)
            if completed.returncode != 0:
                base['error'] = 'Python sandbox stopped before completing this test.'
            else:
                base.update(json.loads(completed.stdout))
        except subprocess.TimeoutExpired:
            # subprocess.run kills and reaps the process before raising.
            base['status'] = 'Time Limit Exceeded'
            base['error'] = 'Execution exceeded 3 seconds.'
        except (ValueError, OSError):
            base['error'] = 'Python sandbox could not produce a valid result.'
        finally:
            capture.cleanup()
        base['elapsed'] = round((time.monotonic() - started) * 1000, 2)
        return base

    def run_question(self, data):
        return [self.run_case(data['code'], test, data.get('preserveInputs', False))
                for test in data['tests']]
