"""One disposable host process; submitted code executes only inside WASI."""
import json
import os
import resource
import sys
from sandbox import Sandbox, OUTPUT_BYTES

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_CPU, (4, 4))
resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
resource.setrlimit(resource.RLIMIT_FSIZE, (OUTPUT_BYTES, OUTPUT_BYTES))
data = json.loads(sys.stdin.read(256 * 1024))
sandbox = Sandbox(compiled=os.environ['WASM_COMPILED_PATH'])
try:
    result = sandbox.run_case(data['code'], data['test'], data.get('preserveInputs', False))
finally:
    sandbox.close()
print(json.dumps(result))
