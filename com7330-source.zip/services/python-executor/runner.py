import json, io, contextlib, ast, traceback, sys, time, copy
class LimitedOutput(io.StringIO):
    def write(self, text):
        if self.tell() + len(text) > 30000:
            raise RuntimeError('Output limit exceeded (30,000 characters).')
        return super().write(text)
def same_value(a, b):
    if isinstance(b, bool):
        return type(a) is bool and a == b
    if isinstance(b, (int, float)):
        return type(a) in (int, float) and abs(a - b) <= 1e-9
    if type(a) is not type(b):
        return False
    if isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(same_value(x,y) for x,y in zip(a,b))
    if isinstance(b, dict):
        return a.keys() == b.keys() and all(same_value(a[k],b[k]) for k in b)
    return a == b
def run_case(payload_text):
    data = json.loads(payload_text)
    test = data['test']
    stdout = LimitedOutput()
    namespace = {'__name__': '__main__'}
    result = {'input':test['input'], 'expected':test['expected'], 'hidden':test['hidden'], 'note':test.get('note',''), 'actual':'', 'stdout':'', 'status':'Runtime Error'}
    if 'stdout' in test:
        result['expectedStdout']=test['stdout']
    started=time.perf_counter()
    oldstdin=sys.stdin
    try:
        sys.stdin=io.StringIO(test.get('stdin',''))
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stdout):
            compiled=compile(data['code'], 'solution.py', 'exec')
            exec(compiled, namespace, namespace)
            call=ast.parse(test['input'], mode='eval').body
            if not isinstance(call, ast.Call) or not isinstance(call.func, ast.Name):
                raise ValueError('Invalid generated test expression')
            args=[ast.literal_eval(arg) for arg in call.args]
            originals=copy.deepcopy(args)
            answer=namespace[call.func.id](*args)
            expected=ast.literal_eval(test['expected'])
        result['actual']=repr(answer)[:30000]
        okay=same_value(answer, expected)
        if 'stdout' in test:
            okay=okay and stdout.getvalue().replace('\r\n','\n') == test['stdout']
        if data.get('preserveInputs') and args != originals:
            okay=False
            result['error']='Input mutation: this question requires the original inputs to remain unchanged.'
        result['status']='Passed' if okay else 'Failed'
    except BaseException as error:
        result['status']='Syntax Error' if isinstance(error, SyntaxError) else 'Runtime Error'
        result['error']=''.join(traceback.format_exception(type(error), error, error.__traceback__, limit=5))[-6000:]
    finally:
        sys.stdin=oldstdin
        result['stdout']=stdout.getvalue()[:30000]
        result['elapsed']=round((time.perf_counter()-started)*1000,2)
    return json.dumps(result)
