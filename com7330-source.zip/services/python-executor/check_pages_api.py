"""Test real HTTP routing, server execution, isolated records and restart persistence."""
import asyncio
import copy
import json
import os
from pathlib import Path
import secrets
import tempfile
from aiohttp import FormData
from aiohttp.test_utils import TestClient, TestServer

os.environ['EXECUTOR_KEY'] = secrets.token_hex(32)
ROOT = Path(__file__).resolve().parents[2]
ORIGIN = 'https://2220732592-sys.github.io'


async def main():
    with tempfile.TemporaryDirectory() as directory:
        os.environ['DATA_DIR'] = directory
        from server import create_app
        from visitor_api import VisitorStore
        async with TestClient(TestServer(create_app())) as client:
            async def session():
                response = await client.post('/api/session',headers={'Origin':ORIGIN})
                assert response.status == 200
                assert response.headers['Access-Control-Allow-Origin'] == ORIGIN
                return {'Authorization':'Visitor '+(await response.json())['token'],'Origin':ORIGIN}
            a,b = await session(),await session()
            assert (await client.get('/api/workspace')).status == 401
            assert (await client.get('/api/workspace',headers={**a,'Origin':'https://untrusted.example'})).status == 403
            assert (await client.get('/api/workspace',headers={'Authorization':a['Authorization'][:-1]+'z'})).status == 401
            preflight = await client.options('/api/execute',headers={'Origin':ORIGIN,'Access-Control-Request-Headers':'authorization,content-type'})
            assert preflight.status == 204 and preflight.headers['Access-Control-Allow-Origin'] == ORIGIN
            first = await (await client.get('/api/workspace',headers=a)).json()
            assert first['workspace'] is None and first['visitor']['kind'] == 'guest'
            seed = json.loads((ROOT/'lib/seed-exam.json').read_text())
            assert len(seed['questions']) == 10 and sum(q['marks'] for q in seed['questions']) == 100
            sem = asyncio.Semaphore(2)
            async def run(question):
                async with sem:
                    response = await client.post('/api/execute',headers=a,json={'code':question['solution'],'tests':question['tests'],'preserveInputs':'do not modify' in question['description'].lower()})
                    result = await response.json()
                    assert response.status == 200 and result['execution'] == 'server', result
                    assert all(r['status']=='Passed' for r in result['results']), result
                    return result['results']
            results = await asyncio.gather(*(run(q) for q in seed['questions']))
            for q, scores in zip(seed['questions'],results):
                seed['answers'][q['id']].update(code=q['solution'],submitted=True,results=scores,submittedCode=q['solution'])
            seed['complete'] = True
            payload = {'sessions':[seed],'materials':[],'activeId':seed['id'],'revision':0}
            saved = await client.put('/api/workspace',headers=a,json=payload)
            assert saved.status == 200 and (await saved.json())['revision'] == 1
            assert (await client.put('/api/workspace',headers=a,json=payload)).status == 409
            assert (await (await client.get('/api/workspace',headers=b)).json())['workspace'] is None
            reloaded = (await (await client.get('/api/workspace',headers=a)).json())['workspace']
            assert reloaded['sessions'][0]['complete'] and reloaded['revision'] == 1
            form = FormData(); form.add_field('file',b'Task: write a function using Python strings.',filename='practice.txt',content_type='text/plain')
            uploaded = await client.post('/api/materials',headers=a,data=form)
            assert uploaded.status == 200, await uploaded.text()
            key = (await uploaded.json())['key']
            assert (Path(directory)/'uploads'/key).read_bytes().startswith(b'Task')
            assert (await client.get('/api/materials/'+key,headers=b)).status in {404,405}
            store = client.server.app['visitor_store']
            visitor = store.db.execute('SELECT visitor FROM workspace').fetchone()[0]
            store.limit(('check',),1)
            from visitor_api import ApiError
            try: store.limit(('check',),1)
            except ApiError as e: assert e.status == 429
            else: raise AssertionError('Rate limit missing')
            print('PASS: 60 server tests, 100 marks, concurrent execution, guest isolation, CORS, invalid credentials, saves, conflicts, uploads, rate limiting',flush=True)
        reopened = VisitorStore(directory)
        assert reopened.read(visitor)['sessions'][0]['complete']
        assert reopened.db.execute('SELECT key FROM uploads').fetchone()[0] == key
        reopened.db.close()
        print('PASS: exercise records and uploaded materials survive backend restart',flush=True)

asyncio.run(main())
