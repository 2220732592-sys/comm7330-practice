"""Anonymous Pages API. User code is executed only by the separate WASI executor."""
import asyncio
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import sqlite3
import time
from aiohttp import web

MIB = 1024 * 1024
ORIGINS = set(os.environ.get('PUBLIC_ORIGINS', 'https://2220732592-sys.github.io').split(','))
TOKEN = re.compile(r'^[0-9a-f]{64}\.[0-9a-f]{64}$')


class ApiError(Exception):
    def __init__(self, message, status=400):
        self.message, self.status = message, status


class VisitorStore:
    def __init__(self, path):
        self.root = Path(path)
        self.root.mkdir(parents=True, exist_ok=True)
        self.uploads = self.root / 'uploads'
        self.uploads.mkdir(exist_ok=True)
        self.db = sqlite3.connect(self.root / 'workspace.sqlite3')
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('PRAGMA journal_size_limit=8388608')
        self.db.execute('CREATE TABLE IF NOT EXISTS workspace (visitor TEXT PRIMARY KEY, payload TEXT NOT NULL, revision INTEGER NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS uploads (key TEXT PRIMARY KEY, visitor TEXT NOT NULL, size INTEGER NOT NULL, name TEXT NOT NULL)')
        self.db.commit()
        self.counts = {}

    def limit(self, key, maximum, seconds=60):
        now = int(time.monotonic())
        previous, count = self.counts.get(key, (now, 0))
        if now - previous >= seconds:
            previous, count = now, 0
        if count >= maximum:
            raise ApiError('请求过于频繁，请稍后重试。', 429)
        if len(self.counts) > 20000:
            self.counts = {k: v for k, v in self.counts.items() if now-v[0] < 3600}
            if len(self.counts) > 20000:
                raise ApiError('当前访问人数较多，请稍后重试。', 503)
        self.counts[key] = (previous, count + 1)

    def free_space(self):
        if shutil.disk_usage(self.root).free < 64 * MIB:
            raise ApiError('服务器存储空间不足；本机草稿仍会保留。', 507)

    def read(self, visitor):
        row = self.db.execute('SELECT payload,revision FROM workspace WHERE visitor=?', (visitor,)).fetchone()
        return {**json.loads(row[0]), 'revision': row[1]} if row else None

    def save(self, visitor, value):
        if not isinstance(value, dict):
            raise ApiError('记录格式错误。')
        revision = value.get('revision', 0)
        sessions = value.get('sessions')
        if type(revision) is not int or revision < 0 or not isinstance(sessions, list) or not 1 <= len(sessions) <= 300 or not isinstance(value.get('materials'), list):
            raise ApiError('记录格式错误。')
        for session in sessions:
            if not isinstance(session, dict) or not isinstance(session.get('questions'), list) or not 1 <= len(session['questions']) <= 20 or not isinstance(session.get('answers'), dict):
                raise ApiError('题目或答案格式错误。')
            if type(session.get('current')) is not int or not 0 <= session['current'] < len(session['questions']):
                raise ApiError('题目索引错误。')
            for question in session['questions']:
                if not isinstance(question, dict) or not isinstance(question.get('id'), str):
                    raise ApiError('题目格式错误。')
                answer = session['answers'].get(question['id'])
                if not isinstance(answer, dict) or not isinstance(answer.get('code'), str) or len(answer['code']) > 50000:
                    raise ApiError('答案格式错误。')
        if not any(s.get('id') == value.get('activeId') for s in sessions):
            raise ApiError('未找到当前练习。')
        payload = json.dumps({k: value[k] for k in ('sessions', 'materials', 'activeId')}, ensure_ascii=False)
        self.free_space()
        with self.db:
            current = self.db.execute('SELECT revision FROM workspace WHERE visitor=?', (visitor,)).fetchone()
            if (current[0] if current else 0) != revision:
                raise ApiError('记录已在其他页面更新。当前草稿已保留，请刷新后检查。', 409)
            size = self.db.execute('SELECT COALESCE(SUM(length(CAST(payload AS BLOB))),0) FROM workspace WHERE visitor!=?', (visitor,)).fetchone()[0]
            if size + len(payload.encode()) > 128 * MIB:
                raise ApiError('服务器记录容量已满；本机草稿仍会保留。', 507)
            self.db.execute('INSERT INTO workspace VALUES (?,?,?) ON CONFLICT(visitor) DO UPDATE SET payload=excluded.payload,revision=excluded.revision', (visitor, payload, revision + 1))
        return revision + 1


def identity(request):
    token = request.headers.get('Authorization', '').removeprefix('Visitor ')
    if not TOKEN.fullmatch(token):
        raise ApiError('访客凭据无效。请重新打开网站。', 401)
    nonce, signature = token.split('.')
    expected = hmac.new(os.environ['EXECUTOR_KEY'].encode(), ('visitor:'+nonce).encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(signature, expected):
        raise ApiError('访客凭据无效。', 401)
    return hashlib.sha256(token.encode()).hexdigest()


@web.middleware
async def public_api(request, handler):
    if not request.path.startswith('/api/'):
        return await handler(request)
    origin = request.headers.get('Origin')
    if origin and origin not in ORIGINS:
        return web.json_response({'error': 'Origin not allowed'}, status=403)
    try:
        if request.method == 'OPTIONS':
            response = web.Response(status=204)
        else:
            store = request.app['visitor_store']
            # Railway's edge appends the connecting client to this header.
            ip = request.headers.get('X-Forwarded-For', request.remote or 'unknown').split(',')[-1].strip()
            ip_key = hashlib.sha256(ip.encode()).hexdigest()
            store.limit(('ip', ip_key), 240)
            request['client_ip_key'] = ip_key
            if request.path != '/api/session':
                request['visitor'] = identity(request)
                scope = request.path.rsplit('/', 1)[-1]
                maximum = {'execute':40, 'workspace':120, 'materials':20}.get(scope, 20)
                store.limit((scope, request['visitor']), maximum, 3600 if scope == 'materials' else 60)
            if request.app['active_api'] >= 24:
                raise ApiError('当前访问人数较多，请稍后重试。', 503)
            request.app['active_api'] += 1
            try:
                response = await handler(request)
            finally:
                request.app['active_api'] -= 1
    except ApiError as error:
        response = web.json_response({'error':error.message}, status=error.status)
    except web.HTTPRequestEntityTooLarge:
        response = web.json_response({'error':'请求内容过大。'}, status=413)
    except (ValueError, TimeoutError):
        response = web.json_response({'error':'请求内容无效或超时。'}, status=400)
    except sqlite3.Error:
        response = web.json_response({'error':'记录保存暂时不可用；请保留本机草稿。'}, status=503)
    response.headers['Cache-Control'] = 'no-store'
    response.headers['Vary'] = 'Origin'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    if origin:
        response.headers['Access-Control-Allow-Origin'] = origin
        response.headers['Access-Control-Allow-Methods'] = 'GET, PUT, POST, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Authorization, Content-Type'
        response.headers['Access-Control-Max-Age'] = '600'
    return response


async def create_session(request):
    store = request.app['visitor_store']
    store.limit(('new',request['client_ip_key']), 30, 3600)
    store.limit(('new-global',), 300, 3600)
    nonce = secrets.token_hex(32)
    signature = hmac.new(os.environ['EXECUTOR_KEY'].encode(), ('visitor:'+nonce).encode(), hashlib.sha256).hexdigest()
    return web.json_response({'token':nonce+'.'+signature})


async def read_workspace(request):
    visitor = request['visitor']
    return web.json_response({'workspace':request.app['visitor_store'].read(visitor),
        'visitor':{'kind':'guest','name':'访客练习','draftKey':'com7330-pages-draft-'+visitor[:16]},
        'execution':{'mode':'server','python':'3.13.15'}})


async def save_workspace(request):
    if request.content_type != 'application/json':
        raise ApiError('请求必须使用 JSON。', 415)
    async with asyncio.timeout(10):
        raw = await request.read()
    if len(raw) > 1800000:
        raise ApiError('学习记录过大，请先导出已完成练习。', 413)
    revision = request.app['visitor_store'].save(request['visitor'], json.loads(raw))
    return web.json_response({'revision':revision})


async def upload_material(request):
    if request.app['active_uploads'] >= 2:
        raise ApiError('当前上传人数较多，请稍后重试。', 503)
    request.app['active_uploads'] += 1
    store = request.app['visitor_store']
    path = None
    try:
        store.free_space()
        async with asyncio.timeout(45):
            multipart = await request.multipart()
            part = await multipart.next()
            if not part or part.name != 'file' or not part.filename:
                raise ApiError('请选择课程文件。')
            name = Path(part.filename).name[:255]
            if Path(name).suffix.lower() not in {'.pdf','.ppt','.pptx','.docx','.txt','.py','.ipynb','.zip'}:
                raise ApiError('不支持此文件格式。')
            key = secrets.token_hex(24)
            path = store.uploads / key
            size = 0
            with path.open('xb') as target:
                while chunk := await part.read_chunk(65536):
                    size += len(chunk)
                    if size > 20*MIB:
                        raise ApiError('文件需小于 20 MB。', 413)
                    target.write(chunk)
            visitor = request['visitor']
            with store.db:
                all_size = store.db.execute('SELECT COALESCE(SUM(size),0) FROM uploads').fetchone()[0]
                own_size = store.db.execute('SELECT COALESCE(SUM(size),0) FROM uploads WHERE visitor=?',(visitor,)).fetchone()[0]
                if all_size + size > 256*MIB or own_size + size > 80*MIB:
                    raise ApiError('资料存储额度已满，请缩小文件或分批整理。', 507)
                store.db.execute('INSERT INTO uploads VALUES (?,?,?,?)',(key,visitor,size,name))
            path = None
        return web.json_response({'key':key})
    finally:
        if path is not None:
            path.unlink(missing_ok=True)
        request.app['active_uploads'] -= 1


async def visitor_lifecycle(app):
    app['visitor_store'] = VisitorStore(os.environ.get('DATA_DIR','/data/com7330'))
    app['active_uploads'] = 0
    app['active_api'] = 0
    yield
    app['visitor_store'].db.close()


def attach(app, execute_handler):
    app.middlewares.append(public_api)
    app.cleanup_ctx.append(visitor_lifecycle)
    app.router.add_post('/api/session', create_session)
    app.router.add_get('/api/workspace', read_workspace)
    app.router.add_put('/api/workspace', save_workspace)
    app.router.add_post('/api/materials', upload_material)
    app.router.add_post('/api/execute', execute_handler)
    app.router.add_route('OPTIONS','/api/{tail:.*}',lambda request:web.Response(status=204))
