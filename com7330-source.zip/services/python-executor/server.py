"""Private authenticated executor API; the public Site proxies authorized sessions."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
import hmac
import json
import logging
import os
from aiohttp import web
from sandbox import Executor, MEMORY_BYTES, TIME_SECONDS

KEY = os.environ.get('EXECUTOR_KEY', '')
if len(KEY) < 40:
    raise RuntimeError('Set a strong EXECUTOR_KEY before starting the executor')
MAX_PENDING = 8
MAX_BODY = 256 * 1024


def validate(data):
    if not isinstance(data, dict) or not isinstance(data.get('code'), str) or len(data['code']) > 50000:
        raise ValueError('Code must contain at most 50,000 characters.')
    tests = data.get('tests')
    if not isinstance(tests, list) or not 1 <= len(tests) <= 6:
        raise ValueError('Submit 1–6 tests per question.')
    for test in tests:
        if not isinstance(test, dict) or not isinstance(test.get('hidden'), bool):
            raise ValueError('Invalid test case.')
        for field in ('input', 'expected'):
            if not isinstance(test.get(field), str) or len(test[field]) > 10000:
                raise ValueError('Invalid test expression.')
        for field in ('note', 'stdin', 'stdout'):
            if field in test and (not isinstance(test[field], str) or len(test[field]) > 30000):
                raise ValueError('Invalid test input/output.')
    if 'preserveInputs' in data and not isinstance(data['preserveInputs'], bool):
        raise ValueError('Invalid input preservation flag.')


async def health(request):
    return web.json_response({'status': 'ok', 'execution': 'server', 'python': '3.13.15',
                              'isolation': 'WASI', 'memoryMiB': MEMORY_BYTES // 1048576,
                              'timeLimitSeconds': TIME_SECONDS, 'concurrentJobs': 2})


async def execute(request):
    if request.path != '/api/execute' and not hmac.compare_digest(request.headers.get('Authorization', ''), 'Bearer ' + KEY):
        return web.json_response({'error': 'Unauthorized'}, status=401)
    app = request.app
    if app['pending'] >= MAX_PENDING:
        return web.json_response({'error': 'Executor busy; retry shortly.'}, status=503,
                                 headers={'Retry-After': '5'})
    app['pending'] += 1
    try:
        try:
            async with asyncio.timeout(5):
                raw = await request.read()
            if len(raw) > MAX_BODY:
                raise ValueError('Execution request is too large')
            data = json.loads(raw)
            validate(data)
        except (ValueError, TimeoutError, web.HTTPRequestEntityTooLarge):
            return web.json_response({'error': 'Invalid or oversized execution request.'}, status=400)
        async with app['slots']:
            results = await asyncio.get_running_loop().run_in_executor(
                app['pool'], app['sandbox'].run_question, data)
        return web.json_response({'results': results, 'execution': 'server', 'python': '3.13.15'},
                                 headers={'Cache-Control': 'no-store'})
    finally:
        app['pending'] -= 1


async def lifecycle(app):
    app['sandbox'] = Executor()
    app['pool'] = ThreadPoolExecutor(max_workers=2, thread_name_prefix='python-wasi')
    app['slots'] = asyncio.Semaphore(2)
    app['pending'] = 0
    yield
    app['pool'].shutdown(wait=True, cancel_futures=True)
    app['sandbox'].close()


def create_app():
    # Multipart uploads stream directly to disk with their own 20 MiB bound.
    app = web.Application(client_max_size=1800000)
    app.cleanup_ctx.append(lifecycle)
    app.router.add_get('/health', health)
    app.router.add_post('/execute', execute)
    from visitor_api import attach
    attach(app, execute)
    return app


if __name__ == '__main__':
    logging.basicConfig(level=logging.WARNING)
    web.run_app(create_app(), host='0.0.0.0', port=int(os.environ.get('PORT', '8080')),
                access_log=None, shutdown_timeout=25, handler_cancellation=False)
