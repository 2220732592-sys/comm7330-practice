"""Reference compatibility plus isolation, resource and concurrency regression checks."""
import json
import os
from pathlib import Path
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from sandbox import Executor

ROOT = Path(__file__).resolve().parents[2]
executor = Executor()
test = dict(input='answer()', expected='True', hidden=False, note='isolation check')

def check(code, status='Passed', case=test):
    result = executor.run_case(code, case)
    assert result['status'] == status, result
    return result

try:
    questions = json.loads((ROOT / 'lib/seed-exam.json').read_text())['questions']
    count = 0
    for q in questions:
        for t in q['tests']:
            result = executor.run_case(q['solution'], t, 'do not modify' in q['description'].lower())
            assert result['status'] == 'Passed', (q['title'], result)
            count += 1
    print(f'PASS: all {count} reference tests under server CPython WASI', flush=True)
    check('def answer():\n return False', 'Failed')
    check('def answer(:\n return True', 'Syntax Error')
    check('def answer():\n return 1/0', 'Runtime Error')
    check('while True: pass', 'Time Limit Exceeded')
    started = time.monotonic()
    check('import time\ndef answer():\n time.sleep(1000)\n return True', 'Time Limit Exceeded')
    assert time.monotonic() - started < 5
    check('def answer():\n return bytearray(256*1024*1024)', 'Runtime Error')
    check('def answer():\n print("x" * 40000)\n return True', 'Runtime Error')
    os.environ['EXECUTOR_KEY'] = 'qa-secret-not-visible-to-submitted-code'
    check('import os\ndef answer():\n return "EXECUTOR_KEY" not in os.environ')
    with tempfile.NamedTemporaryFile() as f:
        f.write(b'private host file'); f.flush()
        check(f'def answer():\n try:\n  open({f.name!r}).read()\n except OSError:\n  return True\n return False')
    check('def answer():\n try:\n  open("/runtime/lib/qa-write.txt", "w").write("bad")\n except OSError:\n  return True\n return False')
    check('def answer():\n try:\n  import socket\n  socket.socket()\n except (OSError, ImportError, AttributeError):\n  return True\n return False')
    check('import os\ndef answer():\n return not hasattr(os, "fork") and not hasattr(os, "system")')
    jobs = [(f'def answer():\n return {n}', dict(test, expected=str(n))) for n in range(6)]
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda job: executor.run_case(job[0], job[1]), jobs))
    assert all(r['status'] == 'Passed' for r in results), results
    print('PASS: errors, infinite loop, blocking sleep, memory, output, environment, host files, read-only stdlib, networking, process creation and concurrent isolation', flush=True)
finally:
    executor.close()
