"""Railway image entrypoint. Only deploy-time configuration is evaluated here."""
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path('/app/com7330-executor')
ROOT.mkdir(parents=True, exist_ok=True)
bundle = json.loads(gzip.decompress(base64.b64decode(os.environ.pop('EXECUTOR_BUNDLE_B64'))))
if set(bundle) != {'server.py', 'sandbox.py', 'runner.py', 'case_worker.py', 'visitor_api.py'}:
    raise RuntimeError('Invalid executor deployment bundle')
for name, code in bundle.items():
    (ROOT / name).write_text(code, encoding='utf-8')
os.environ.pop('EXECUTOR_BOOTSTRAP_B64', None)
subprocess.run([sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check',
                '--no-cache-dir', 'wasmtime==49.0.0', 'aiohttp==3.14.3'], check=True)
url = 'https://github.com/brettcannon/cpython-wasi-build/releases/download/v3.13.15/python-3.13.15-wasi_sdk-24.zip'
with urllib.request.urlopen(url, timeout=60) as response:
    data = response.read(20_000_000)
if hashlib.sha256(data).hexdigest() != '67e1c32a85d5e0600c0939f5fd4023ca0127f1a9e81f5499697467bda67af78d':
    raise RuntimeError('Python runtime checksum mismatch')
runtime = ROOT / 'runtime'
runtime.mkdir(exist_ok=True)
with zipfile.ZipFile(io.BytesIO(data)) as archive:
    for name in archive.namelist():
        target = (runtime / name).resolve()
        if not target.is_relative_to(runtime.resolve()):
            raise RuntimeError('Invalid runtime archive path')
    archive.extractall(runtime)
os.environ['PYTHON_WASI_ROOT'] = str(runtime)
os.chdir(ROOT)
if not os.path.ismount('/data'):
    raise RuntimeError('A persistent Railway volume must be mounted at /data before enabling visitor records')
data_dir = Path('/data/com7330')
data_dir.mkdir(parents=True, exist_ok=True)
os.environ['DATA_DIR'] = str(data_dir)
# The HTTP service does not need root. WASI guests receive no process credentials.
if os.geteuid() == 0:
    os.chown(data_dir, 65534, 65534)
    os.setgroups([])
    os.setgid(65534)
    os.setuid(65534)
os.execv(sys.executable, [sys.executable, '-u', str(ROOT / 'server.py')])
