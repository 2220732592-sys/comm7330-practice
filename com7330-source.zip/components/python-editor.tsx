'use client';
import {useEffect,useRef} from 'react';
import {EditorState,Compartment} from '@codemirror/state';
import {EditorView,lineNumbers,highlightActiveLine,highlightActiveLineGutter,keymap,drawSelection} from '@codemirror/view';
import {python} from '@codemirror/lang-python';
import {defaultKeymap,history,historyKeymap,indentWithTab} from '@codemirror/commands';
import {syntaxHighlighting,defaultHighlightStyle,indentUnit,bracketMatching} from '@codemirror/language';
import {closeBrackets,closeBracketsKeymap} from '@codemirror/autocomplete';
export default function PythonEditor({code,onChange,onRun,disabled=false}:{code:string;onChange:(s:string)=>void;onRun:()=>void;disabled?:boolean}){
 const host=useRef<HTMLDivElement>(null),view=useRef<EditorView|null>(null),callbacks=useRef({onChange,onRun}),editable=useRef(new Compartment());callbacks.current={onChange,onRun};
 useEffect(()=>{if(!host.current)return;const v=new EditorView({parent:host.current,state:EditorState.create({doc:code,extensions:[lineNumbers(),highlightActiveLine(),highlightActiveLineGutter(),drawSelection(),history(),python(),syntaxHighlighting(defaultHighlightStyle),indentUnit.of('    '),bracketMatching(),closeBrackets(),keymap.of([{key:'Mod-Enter',run:()=>{callbacks.current.onRun();return true;}},indentWithTab,...defaultKeymap,...historyKeymap,...closeBracketsKeymap]),editable.current.of(EditorView.editable.of(!disabled)),EditorView.contentAttributes.of({'aria-label':'Python code editor',spellcheck:'false'}),EditorView.updateListener.of(u=>{if(u.docChanged)callbacks.current.onChange(u.state.doc.toString());}),EditorView.theme({'&':{fontSize:'15px',backgroundColor:'#fcfdff',minHeight:'255px'},'.cm-scroller':{fontFamily:'"SFMono-Regular",Consolas,"Liberation Mono",monospace',lineHeight:'1.85',overflow:'auto'},'.cm-content':{padding:'18px 0'},'.cm-gutters':{background:'#f8faff',color:'#9aa8bb',border:'none',padding:'0 10px 0 8px'},'.cm-activeLine':{background:'#eef4ff88'},'.cm-activeLineGutter':{background:'#eef4ff'},'&.cm-focused':{outline:'none'},'.cm-line':{padding:'0 14px'},'.cm-cursor':{borderLeftColor:'#2760df'}})]})});view.current=v;return()=>{v.destroy();view.current=null;};},[]);
 useEffect(()=>{const v=view.current;if(v&&v.state.doc.toString()!==code)v.dispatch({changes:{from:0,to:v.state.doc.length,insert:code}});},[code]);
 useEffect(()=>{view.current?.dispatch({effects:editable.current.reconfigure(EditorView.editable.of(!disabled))});},[disabled]);
 return <div ref={host} className="code-editor"/>;
}
