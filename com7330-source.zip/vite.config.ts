import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {fileURLToPath,URL} from 'node:url';

export default defineConfig({
 base:process.env.PAGES_BASE_PATH||'/comm7330-practice/',
 plugins:[react()],
 resolve:{alias:{'@':fileURLToPath(new URL('.',import.meta.url))}},
 build:{outDir:'dist',sourcemap:false},
 server:{host:'0.0.0.0',port:4173,allowedHosts:['terminal.local']},
 preview:{host:'0.0.0.0',port:4173,allowedHosts:['terminal.local']},
});
